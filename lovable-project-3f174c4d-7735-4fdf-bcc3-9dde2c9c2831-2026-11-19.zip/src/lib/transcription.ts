export type TargetStem = "melody_lead" | "accompaniment" | "full_mix";
export interface TranscriptionResult {
  musicxml: string;
  midi_base64: string;
  isolated_audio_base64: string;
  backing_track_base64: string | null;
  metadata: { bpm: number; key: string; total_notes: number; time_signature?: string };
}
export const MAX_FILE_SIZE = 150 * 1024 * 1024;
export function validateAudioFile(file: Pick<File, "name" | "size">): string | null {
  if (!/\.(mp4|mp3|wav)$/i.test(file.name)) return "Escolha um arquivo MP4, MP3 ou WAV.";
  if (file.size === 0) return "O arquivo está vazio.";
  if (file.size > MAX_FILE_SIZE) return "O arquivo deve ter até 150 MB.";
  return null;
}
export function downloadBlob(blob: Blob, name: string) {
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement("a");
  anchor.href = url;
  anchor.download = name;
  anchor.click();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}
export function base64Blob(data: string, type: string): Blob {
  return new Blob([Uint8Array.from(atob(data), (c) => c.charCodeAt(0))], { type });
}
export function demoXml(clef: "treble" | "bass" = "treble"): string {
  const measures = [
    ["E", "G", "A", "G"],
    ["F", "A", "G", "E"],
    ["D", "F", "E", "D"],
    ["C", "E", "G", "C"],
    ["A", "G", "F", "E"],
    ["D", "E", "F", "G"],
    ["E", "G", "D", "F"],
    ["C", "E", "G", "C"],
  ];
  return `<?xml version="1.0" encoding="utf-8"?><score-partwise version="4.0"><work><work-title>Pequeno estudo</work-title></work><identification><creator type="composer">Partitura Studio</creator></identification><part-list><score-part id="P1"><part-name>Piano</part-name></score-part></part-list><part id="P1">${measures.map((notes, i) => `<measure number="${i + 1}">${i === 0 ? `<attributes><divisions>1</divisions><key><fifths>0</fifths></key><time><beats>4</beats><beat-type>4</beat-type></time><clef><sign>${clef === "treble" ? "G" : "F"}</sign><line>${clef === "treble" ? 2 : 4}</line></clef></attributes><direction placement="above"><direction-type><metronome><beat-unit>quarter</beat-unit><per-minute>96</per-minute></metronome></direction-type><sound tempo="96"/></direction>` : ""}${notes.map((n) => `<note><pitch><step>${n}</step><octave>${clef === "treble" ? 4 : 3}</octave></pitch><duration>1</duration><type>quarter</type></note>`).join("")}</measure>`).join("")}</part></score-partwise>`;
}
export function demoAudio(backing = false): Blob {
  const rate = 22050,
    seconds = 20,
    samples = rate * seconds;
  const buffer = new ArrayBuffer(44 + samples * 2),
    view = new DataView(buffer);
  const text = (offset: number, s: string) =>
    [...s].forEach((c, i) => view.setUint8(offset + i, c.charCodeAt(0)));
  text(0, "RIFF");
  view.setUint32(4, 36 + samples * 2, true);
  text(8, "WAVE");
  text(12, "fmt ");
  view.setUint32(16, 16, true);
  view.setUint16(20, 1, true);
  view.setUint16(22, 1, true);
  view.setUint32(24, rate, true);
  view.setUint32(28, rate * 2, true);
  view.setUint16(32, 2, true);
  view.setUint16(34, 16, true);
  text(36, "data");
  view.setUint32(40, samples * 2, true);
  const notes = [
    64, 67, 69, 67, 65, 69, 67, 64, 62, 65, 64, 62, 60, 64, 67, 60, 69, 67, 65, 64, 62, 64, 65, 67,
    64, 67, 62, 65, 60, 64, 67, 60,
  ];
  for (let i = 0; i < samples; i++) {
    const t = i / rate,
      beat = t / 0.625,
      index = Math.floor(beat),
      age = (beat - index) * 0.625;
    const note = (notes[index % notes.length] ?? 60) - (backing ? 12 : 0);
    const f = 440 * 2 ** ((note - 69) / 12);
    const value = Math.sin(2 * Math.PI * f * t) * Math.exp(-age * 6) * (backing ? 0.13 : 0.22);
    view.setInt16(44 + i * 2, value * 32767, true);
  }
  return new Blob([buffer], { type: "audio/wav" });
}
