import { useEffect, useRef, useState } from "react";
import { Download, Headphones, Pause, Play, Volume2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { downloadBlob } from "@/lib/transcription";
const heights = [
  16, 25, 12, 29, 36, 20, 42, 30, 19, 35, 48, 23, 32, 45, 27, 18, 37, 52, 29, 42, 24, 36, 49, 28,
  16, 38, 25, 47, 31, 19, 43, 28, 34, 20, 46, 32, 24, 39, 18, 29, 44, 26, 35, 17, 42, 31, 20, 38,
];
const time = (n: number) => `${Math.floor(n / 60)}:${String(Math.floor(n % 60)).padStart(2, "0")}`;
export function AudioPlayer({
  title,
  subtitle,
  blob,
  name,
  kind,
}: {
  title: string;
  subtitle: string;
  blob: Blob | null;
  name: string;
  kind: "isolated" | "backing";
}) {
  const audio = useRef<HTMLAudioElement>(null);
  const [url, setUrl] = useState("");
  const [playing, setPlaying] = useState(false);
  const [position, setPosition] = useState(0);
  const [duration, setDuration] = useState(0);
  useEffect(() => {
    setPlaying(false);
    setPosition(0);
    setDuration(0);
    if (!blob) {
      setUrl("");
      return;
    }
    const next = URL.createObjectURL(blob);
    setUrl(next);
    return () => URL.revokeObjectURL(next);
  }, [blob]);
  return (
    <div className={`audio-track ${kind}`}>
      <div className="track-heading">
        <span className="track-icon">
          {kind === "isolated" ? <Volume2 size={17} /> : <Headphones size={17} />}
        </span>
        <div>
          <h3>{title}</h3>
          <p>{subtitle}</p>
        </div>
        <Button
          variant="ghost"
          size="icon"
          title={`Baixar ${title}`}
          aria-label={`Baixar ${title}`}
          disabled={!blob}
          onClick={() => blob && downloadBlob(blob, name)}
        >
          <Download />
        </Button>
      </div>
      <div className="track-controls">
        <Button
          variant="outline"
          size="icon"
          className="play-button"
          aria-label={`${playing ? "Pausar" : "Ouvir"} ${title}`}
          disabled={!url}
          onClick={async () => {
            if (!audio.current) return;
            if (playing) audio.current.pause();
            else
              try {
                await audio.current.play();
              } catch {
                setPlaying(false);
              }
          }}
        >
          {playing ? <Pause /> : <Play />}
        </Button>
        <div className="waveform" aria-hidden="true">
          {heights.map((h, i) => (
            <span
              className={i / heights.length < position / Math.max(duration, 1) ? "played" : ""}
              key={i}
              data-height={h}
            />
          ))}
        </div>
        <span className="track-time">
          {time(position)} / {time(duration)}
        </span>
      </div>
      <input
        className="audio-seek"
        aria-label={`Posição de ${title}`}
        type="range"
        min={0}
        max={duration || 1}
        step={0.1}
        value={position}
        disabled={!url}
        onChange={(e) => {
          if (audio.current) {
            audio.current.currentTime = Number(e.target.value);
            setPosition(Number(e.target.value));
          }
        }}
      />
      <audio
        ref={audio}
        src={url || undefined}
        onLoadedMetadata={() => setDuration(audio.current?.duration || 0)}
        onTimeUpdate={() => setPosition(audio.current?.currentTime || 0)}
        onPlay={() => setPlaying(true)}
        onPause={() => setPlaying(false)}
        onEnded={() => setPlaying(false)}
      />
    </div>
  );
}
