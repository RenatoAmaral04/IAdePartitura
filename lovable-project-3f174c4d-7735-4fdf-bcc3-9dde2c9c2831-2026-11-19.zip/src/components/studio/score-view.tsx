import { useEffect, useRef, useState } from "react";

export function ScoreView({ xml, zoom }: { xml: string; zoom: number }) {
  const container = useRef<HTMLDivElement>(null);
  const [error, setError] = useState("");
  useEffect(() => {
    let disposed = false;
    const node = container.current;
    if (!node) return;
    setError("");
    const render = async () => {
      try {
        const { OpenSheetMusicDisplay } = await import("opensheetmusicdisplay");
        if (disposed) return;
        node.replaceChildren();
        const display = new OpenSheetMusicDisplay(node, {
          autoResize: true,
          backend: "svg",
          drawingParameters: "default",
          drawTitle: true,
          drawSubtitle: false,
        });
        await display.load(xml);
        if (disposed) return;
        display.Zoom = zoom;
        display.render();
      } catch {
        if (!disposed)
          setError("Não foi possível abrir esta partitura. Você ainda pode baixar o MusicXML.");
      }
    };
    void render();
    return () => {
      disposed = true;
      node.replaceChildren();
    };
  }, [xml, zoom]);
  return (
    <div className="score-content">
      {error && <p className="text-destructive p-6">{error}</p>}
      <div ref={container} />
    </div>
  );
}
