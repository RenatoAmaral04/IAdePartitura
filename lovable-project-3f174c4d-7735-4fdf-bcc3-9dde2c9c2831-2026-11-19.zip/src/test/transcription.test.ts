import { describe, expect, it } from "vitest";
import { validateAudioFile } from "@/lib/transcription";
describe("Upload rules", () => {
  it("accepts the three requested formats", () => {
    for (const ext of ["mp4", "mp3", "wav"])
      expect(validateAudioFile({ name: `song.${ext}`, size: 100 })).toBeNull();
    expect(validateAudioFile({ name: "song.pdf", size: 100 })).not.toBeNull();
  });
  it("enforces the same 150 MB limit as the API", () => {
    expect(validateAudioFile({ name: "song.mp3", size: 150 * 1024 * 1024 })).toBeNull();
    expect(validateAudioFile({ name: "song.mp3", size: 150 * 1024 * 1024 + 1 })).not.toBeNull();
  });
});
