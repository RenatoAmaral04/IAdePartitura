import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useRef, useState } from "react";
import {
  ArrowRight,
  AudioLines,
  Check,
  ChevronDown,
  FileAudio,
  FileMusic,
  Headphones,
  Info,
  LoaderCircle,
  LockKeyhole,
  Mic2,
  Music2,
  Piano,
  Play,
  Printer,
  Settings2,
  ShieldCheck,
  Sparkles,
  Upload,
  X,
  ZoomIn,
  ZoomOut,
  Download,
  Maximize2,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Slider } from "@/components/ui/slider";
import { ScoreView } from "@/components/studio/score-view";
import { AudioPlayer } from "@/components/studio/audio-player";
import {
  base64Blob,
  demoAudio,
  demoXml,
  downloadBlob,
  validateAudioFile,
  type TargetStem,
  type TranscriptionResult,
} from "@/lib/transcription";
export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Partitura Studio — Transcrição musical & playback" },
      {
        name: "description",
        content:
          "Transforme áudio e vídeo em partituras, MIDI e acompanhamento para estudar música.",
      },
      { property: "og:title", content: "Partitura Studio — Seu estúdio de partituras" },
      {
        property: "og:description",
        content: "Separe instrumentos, transcreva músicas e ensaie com playback.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});
const stems = [
  {
    value: "melody_lead" as const,
    title: "Melodia principal / Solo",
    description: "Voz e linha melódica. Playback sem a melodia.",
    icon: Mic2,
  },
  {
    value: "accompaniment" as const,
    title: "Acompanhamento harmônico",
    description: "Piano, violão e acordes. Sem bateria e baixo.",
    icon: Piano,
  },
  {
    value: "full_mix" as const,
    title: "Áudio completo",
    description: "Sem separação. Ideal para um instrumento solo.",
    icon: AudioLines,
  },
];
function Index() {
  const [file, setFile] = useState<File | null>(null),
    [stem, setStem] = useState<TargetStem>("melody_lead"),
    [clef, setClef] = useState<"treble" | "bass">("treble");
  const [onset, setOnset] = useState(0.5),
    [frame, setFrame] = useState(0.3),
    [length, setLength] = useState(127.7),
    [dragging, setDragging] = useState(false),
    [error, setError] = useState(""),
    [processing, setProcessing] = useState(false),
    [stage, setStage] = useState(0),
    [zoom, setZoom] = useState(0.85);
  const [result, setResult] = useState<TranscriptionResult | null>(null),
    [isolated, setIsolated] = useState<Blob | null>(null),
    [backing, setBacking] = useState<Blob | null>(null);
  const [api, setApi] = useState(
      import.meta.env["VITE_TRANSCRIPTION_API_URL"] || "http://localhost:8000",
    ),
    [draftApi, setDraftApi] = useState(api),
    [settings, setSettings] = useState(false),
    [online, setOnline] = useState(false),
    [checking, setChecking] = useState(false);
  const fileInput = useRef<HTMLInputElement>(null),
    request = useRef<AbortController | null>(null),
    resultArea = useRef<HTMLElement>(null);
  useEffect(() => () => request.current?.abort(), []);
  useEffect(() => {
    const ctrl = new AbortController();
    fetch(`${api.replace(/\/$/, "")}/health`, { signal: ctrl.signal })
      .then((r) => setOnline(r.ok))
      .catch(() => setOnline(false));
    return () => ctrl.abort();
  }, [api]);
  useEffect(() => {
    if (!processing) return;
    const timer = setInterval(
      () => setStage((s) => Math.min(s + 1, 2)),
      stem === "full_mix" ? 5000 : 20000,
    );
    return () => clearInterval(timer);
  }, [processing, stem]);
  const chooseFile = (next: File | undefined) => {
    if (!next) return;
    const issue = validateAudioFile(next);
    setError(issue || "");
    if (!issue) setFile(next);
  };
  const sample = () => {
    setResult(null);
    setIsolated(demoAudio());
    setBacking(demoAudio(true));
    setError("");
  };
  const transcribe = async () => {
    if (!file) return;
    setError("");
    setProcessing(true);
    setStage(0);
    const ctrl = new AbortController();
    request.current = ctrl;
    const form = new FormData();
    form.append("file", file);
    form.append("target_stem", stem);
    form.append("clef", clef);
    form.append("onset_threshold", String(onset));
    form.append("frame_threshold", String(frame));
    form.append("minimum_note_length", String(length));
    try {
      const response = await fetch(`${api.replace(/\/$/, "")}/transcribe`, {
        method: "POST",
        body: form,
        signal: ctrl.signal,
      });
      if (!response.ok) {
        const info = await response.json().catch(() => null);
        throw new Error(
          typeof info?.detail === "string"
            ? info.detail
            : `O serviço retornou um erro (${response.status}). Confira os ajustes e tente novamente.`,
        );
      }
      const data: TranscriptionResult = await response.json();
      if (!data.musicxml || !data.midi_base64 || !data.isolated_audio_base64 || !data.metadata)
        throw new Error("O serviço retornou um resultado incompleto.");
      setIsolated(base64Blob(data.isolated_audio_base64, "audio/mpeg"));
      setBacking(
        data.backing_track_base64 ? base64Blob(data.backing_track_base64, "audio/mpeg") : null,
      );
      setResult(data);
      setOnline(true);
      resultArea.current?.scrollIntoView({ behavior: "smooth", block: "start" });
    } catch (e) {
      if (e instanceof Error && e.name === "AbortError")
        setError("Cancelado no navegador. A API pode continuar até terminar.");
      else
        setError(
          e instanceof TypeError
            ? "Não foi possível conectar à API de áudio. Abra as configurações e informe o endereço do serviço Python."
            : e instanceof Error
              ? e.message
              : "Não foi possível processar.",
        );
    } finally {
      setProcessing(false);
      request.current = null;
    }
  };
  const xml = result?.musicxml || demoXml(clef),
    filename = result && file ? file.name.replace(/\.[^.]+$/, "") : "pequeno-estudo";
  const connect = async () => {
    setChecking(true);
    try {
      const url = new URL(draftApi);
      if (!["http:", "https:"].includes(url.protocol)) throw new Error();
      const clean = draftApi.replace(/\/$/, "");
      const response = await fetch(`${clean}/health`, { signal: AbortSignal.timeout(10000) });
      if (!response.ok) throw new Error();
      setApi(clean);
      setOnline(true);
      setSettings(false);
      setError("");
    } catch {
      setError("Não foi possível conectar. Confira o endereço, o CORS e se a API está rodando.");
    } finally {
      setChecking(false);
    }
  };
  return (
    <>
      <header className="studio-header">
        <div className="brand">
          <span className="brand-symbol">
            <Music2 size={24} />
          </span>
          Partitura Studio
        </div>
        <div className="header-right">
          <span className="studio-tab">
            <AudioLines size={15} /> Estúdio
          </span>
          <span className="header-status">
            <span className={`status-dot ${online ? "online" : ""}`} />
            {online ? "API conectada" : "API local não conectada"}
          </span>
          <Button
            variant="ghost"
            size="icon"
            aria-label="Configurar API"
            title="Configurar API"
            onClick={() => {
              setDraftApi(api);
              setSettings(true);
            }}
          >
            <Settings2 />
          </Button>
        </div>
      </header>
      <main className="studio-main">
        <div className="workspace-heading">
          <div>
            <div className="eyebrow">
              <Sparkles size={12} /> MAIS TEMPO TOCANDO, MENOS TEMPO TRANSCREVENDO
            </div>
            <h1>Seu estúdio de partituras</h1>
            <p className="intro">Uma música, suas notas e um novo jeito de ensaiar.</p>
          </div>
          <Button variant="outline" size="sm" onClick={sample}>
            <Play size={13} /> Ouvir exemplo
          </Button>
        </div>
        <div className="workspace-grid">
          <section className="configuration" aria-label="Configuração da transcrição">
            <div className="config-section">
              <h2 className="section-title">
                <span className="step-number">1</span> Sua música
              </h2>
              <input
                ref={fileInput}
                type="file"
                className="hidden"
                accept=".mp4,.mp3,.wav"
                aria-label="Selecionar arquivo de música"
                onChange={(e) => chooseFile(e.target.files?.[0])}
                disabled={processing}
              />
              <div
                className={`dropzone ${dragging ? "dragging" : ""}`}
                role="button"
                tabIndex={processing ? -1 : 0}
                aria-label="Enviar música"
                aria-disabled={processing}
                onClick={() => !processing && fileInput.current?.click()}
                onKeyDown={(e) => {
                  if (!processing && ["Enter", " "].includes(e.key)) {
                    e.preventDefault();
                    fileInput.current?.click();
                  }
                }}
                onDragOver={(e) => {
                  e.preventDefault();
                  if (!processing) setDragging(true);
                }}
                onDragLeave={() => setDragging(false)}
                onDrop={(e) => {
                  e.preventDefault();
                  setDragging(false);
                  if (!processing) chooseFile(e.dataTransfer.files[0]);
                }}
              >
                <span className="upload-symbol">
                  {file ? <FileAudio size={22} /> : <Upload size={22} />}
                </span>
                <div className="drop-title">
                  {file ? (
                    file.name
                  ) : (
                    <>
                      Arraste sua música ou <span>escolha um arquivo</span>
                    </>
                  )}
                </div>
                <span className="drop-subtitle">
                  {file
                    ? `${(file.size / 1024 / 1024).toFixed(1)} MB · Clique para trocar`
                    : "MP3, WAV ou MP4 · Até 150 MB"}
                </span>
              </div>
              <p className="upload-note">
                <LockKeyhole size={11} /> Arquivos temporários são excluídos após o processamento.
              </p>
            </div>
            <div className="config-section">
              <h2 className="section-title">
                <span className="step-number">2</span> O que você quer transcrever?
              </h2>
              <div className="stem-list">
                {stems.map((item) => (
                  <Button
                    key={item.value}
                    variant="stem"
                    aria-pressed={stem === item.value}
                    disabled={processing}
                    onClick={() => setStem(item.value)}
                  >
                    <span className="stem-icon">
                      <item.icon size={19} />
                    </span>
                    <span className="stem-copy">
                      <strong>{item.title}</strong>
                      <small>{item.description}</small>
                    </span>
                    <span className="radio-dot" />
                  </Button>
                ))}
              </div>
            </div>
            <div className="config-section">
              <h2 className="section-title">
                <span className="step-number">3</span> Ajuste sua partitura
              </h2>
              <div className="clef-options">
                <Button
                  variant="segment"
                  aria-pressed={clef === "treble"}
                  disabled={processing}
                  onClick={() => setClef("treble")}
                >
                  <span className="clef-symbol">𝄞</span> Clave de Sol
                </Button>
                <Button
                  variant="segment"
                  aria-pressed={clef === "bass"}
                  disabled={processing}
                  onClick={() => setClef("bass")}
                >
                  <span className="clef-symbol">𝄢</span> Clave de Fá
                </Button>
              </div>
              <details className="advanced">
                <summary>
                  <span className="flex items-center gap-2">
                    <Settings2 size={13} /> Sensibilidade das notas
                  </span>
                  <ChevronDown size={13} />
                </summary>
                {[
                  {
                    label: "Limiar de início",
                    value: onset,
                    set: setOnset,
                    min: 0,
                    max: 1,
                    step: 0.01,
                  },
                  {
                    label: "Limiar de sustentação",
                    value: frame,
                    set: setFrame,
                    min: 0,
                    max: 1,
                    step: 0.01,
                  },
                  {
                    label: "Duração mínima (ms)",
                    value: length,
                    set: setLength,
                    min: 10,
                    max: 1000,
                    step: 1,
                  },
                ].map((item) => (
                  <div className="slider-field" key={item.label}>
                    <label>
                      {item.label}
                      <span>{item.value}</span>
                    </label>
                    <Slider
                      aria-label={item.label}
                      min={item.min}
                      max={item.max}
                      step={item.step}
                      value={[item.value]}
                      disabled={processing}
                      onValueChange={(v) => item.set(v[0] ?? item.min)}
                    />
                  </div>
                ))}
              </details>
            </div>
            <Button
              className="transcribe-button"
              disabled={!file || processing}
              onClick={transcribe}
            >
              {processing ? <LoaderCircle className="spin" /> : <Sparkles />}
              {processing ? "Transcrevendo sua música…" : "Gerar partitura"}
              {!processing && <ArrowRight />}
            </Button>
            {processing ? (
              <>
                <div className="progress-steps" aria-live="polite">
                  {[
                    "Extraindo áudio",
                    stem === "full_mix" ? "Analisando notas" : "Separando instrumentos",
                    "Escrevendo partitura",
                  ].map((s, i) => (
                    <span key={s} className={i === stage ? "current" : ""}>
                      {i < stage ? "✓ " : ""}
                      {s}
                    </span>
                  ))}
                </div>
                <p className="process-note">Etapa estimada · Pode levar alguns minutos.</p>
                <Button
                  variant="ghost"
                  size="sm"
                  className="w-full"
                  onClick={() => request.current?.abort()}
                >
                  <X /> Cancelar
                </Button>
              </>
            ) : (
              <p className="process-note">Demucs + Basic Pitch · Feito para quem faz música</p>
            )}
            {error && (
              <p className="error-notice" role="alert">
                {error}
              </p>
            )}
          </section>
          <section ref={resultArea} aria-label="Partitura e playback">
            <div className="result-header">
              <h2>
                <FileMusic size={17} /> Partitura & playback{" "}
                {!result && <span className="example-tag">EXEMPLO</span>}
              </h2>
              {result && <Check size={15} className="text-primary" />}
            </div>
            <p className="result-caption">
              {result
                ? "Sua transcrição está pronta para tocar."
                : "Pequeno estudo · Piano · Prévia de exemplo"}
            </p>
            <div className="score-shell">
              <div className="score-toolbar">
                <span className="score-file">
                  <FileMusic size={12} />
                  {filename}.musicxml
                </span>
                <div className="score-tools">
                  <Button
                    variant="ghost"
                    size="icon"
                    aria-label="Diminuir zoom"
                    title="Diminuir zoom"
                    disabled={zoom <= 0.5}
                    onClick={() => setZoom((z) => Math.max(0.5, z - 0.1))}
                  >
                    <ZoomOut />
                  </Button>
                  <span>{Math.round(zoom * 100)}%</span>
                  <Button
                    variant="ghost"
                    size="icon"
                    aria-label="Aumentar zoom"
                    title="Aumentar zoom"
                    disabled={zoom >= 1.5}
                    onClick={() => setZoom((z) => Math.min(1.5, z + 0.1))}
                  >
                    <ZoomIn />
                  </Button>
                  <Button
                    variant="ghost"
                    size="icon"
                    aria-label="Restaurar zoom"
                    title="Restaurar zoom"
                    onClick={() => setZoom(0.85)}
                  >
                    <Maximize2 />
                  </Button>
                </div>
              </div>
              <div className="score-viewport">
                <ScoreView xml={xml} zoom={zoom} />
              </div>
              <div className="score-metadata">
                <span>
                  <AudioLines size={12} />
                  {result?.metadata.bpm || 96} BPM
                </span>
                <span>
                  <Music2 size={12} />
                  {result?.metadata.key || "Dó maior"}
                </span>
                <span>{result?.metadata.time_signature || "4/4"}</span>
                <span>{result?.metadata.total_notes ?? 32} notas</span>
              </div>
            </div>
            <h3 className="audio-section-title">
              <Headphones size={14} /> SEU ENSAIO COMEÇA AQUI
            </h3>
            <AudioPlayer
              title="Faixa isolada"
              subtitle={
                result ? "O áudio que deu origem à sua partitura" : "Melodia do estudo de exemplo"
              }
              blob={isolated}
              name={`${filename}-isolado.${result ? "mp3" : "wav"}`}
              kind="isolated"
            />
            <AudioPlayer
              title="Playback de acompanhamento"
              subtitle={
                result
                  ? backing
                    ? stem === "accompaniment"
                      ? "Faixa harmônica isolada"
                      : "A música completa, sem a melodia principal"
                    : "Não disponível no modo áudio completo"
                  : "Acompanhamento do estudo de exemplo"
              }
              blob={backing}
              name={`${filename}-playback.${result ? "mp3" : "wav"}`}
              kind="backing"
            />
            <div className="export-row">
              <Button
                variant="outline"
                onClick={() =>
                  downloadBlob(
                    new Blob([xml], { type: "application/vnd.recordare.musicxml+xml" }),
                    `${filename}.musicxml`,
                  )
                }
              >
                <Download /> MusicXML
              </Button>
              <Button
                variant="outline"
                disabled={!result}
                onClick={() =>
                  result &&
                  downloadBlob(base64Blob(result.midi_base64, "audio/midi"), `${filename}.mid`)
                }
              >
                <Download /> MIDI
              </Button>
              <Button variant="outline" onClick={() => window.print()}>
                <Printer /> Imprimir / PDF
              </Button>
            </div>
            <p className="result-note">
              <Info size={11} />{" "}
              {result
                ? "A transcrição por IA pode precisar de pequenos ajustes musicais."
                : "A prévia é um exemplo, não uma transcrição do seu arquivo."}
            </p>
          </section>
        </div>
        <footer className="studio-footer">
          <span className="flex items-center gap-1.5">
            <ShieldCheck size={12} /> Sua música continua sendo sua.
          </span>
          <span>Separação por Demucs · Transcrição por Spotify Basic Pitch</span>
          <Button
            variant="link"
            className="h-auto p-0 text-[10px]"
            onClick={() => setSettings(true)}
          >
            Conexão com a API
          </Button>
        </footer>
      </main>
      {settings && (
        <div
          className="connection-dialog"
          onClick={(e) => {
            if (e.target === e.currentTarget) setSettings(false);
          }}
        >
          <section
            className="connection-panel"
            role="dialog"
            aria-modal="true"
            aria-labelledby="connection-title"
          >
            <div className="flex items-center justify-between">
              <h2 id="connection-title">Conectar serviço de áudio</h2>
              <Button
                variant="ghost"
                size="icon"
                aria-label="Fechar configurações"
                onClick={() => setSettings(false)}
              >
                <X />
              </Button>
            </div>
            <label htmlFor="api-url">Endereço da API Python</label>
            <Input
              id="api-url"
              type="url"
              value={draftApi}
              onChange={(e) => setDraftApi(e.target.value)}
              autoFocus
            />
            <p>
              A separação e a transcrição são executadas pelo serviço Python. Em um site publicado,
              use um endereço HTTPS público.
            </p>
            <div className="flex justify-end gap-2">
              <Button variant="outline" onClick={() => setSettings(false)}>
                Cancelar
              </Button>
              <Button disabled={checking} onClick={connect}>
                {checking ? <LoaderCircle className="spin" /> : <Check />}Testar e conectar
              </Button>
            </div>
            {error && (
              <p role="alert" className="error-notice">
                {error}
              </p>
            )}
          </section>
        </div>
      )}
    </>
  );
}
