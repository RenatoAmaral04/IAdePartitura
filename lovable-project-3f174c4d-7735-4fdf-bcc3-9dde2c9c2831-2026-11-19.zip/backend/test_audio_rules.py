import unittest
from audio_rules import stem_plan, valid_filename


class PipelineRules(unittest.TestCase):
    def test_melody_is_vocals(self):
        self.assertEqual(stem_plan("melody_lead")[0], "vocals")

    def test_melody_playback_excludes_vocals(self):
        self.assertEqual(stem_plan("melody_lead")[1], ("drums", "bass", "other"))

    def test_accompaniment_is_other(self):
        self.assertEqual(stem_plan("accompaniment"), ("other", ("other",)))

    def test_full_mix_skips_separation(self):
        self.assertEqual(stem_plan("full_mix"), (None, ()))

    def test_formats(self):
        for name in ["song.mp4", "song.mp3", "song.wav"]:
            self.assertTrue(valid_filename(name))
        self.assertFalse(valid_filename("song.exe"))


if __name__ == "__main__":
    unittest.main()