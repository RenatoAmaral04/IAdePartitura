"""Standalone Python API. Deploy separately from the web application."""
import base64
import logging
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import threading
from typing import Literal

from fastapi import FastAPI, File, Form, HTTPException, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from audio_rules import stem_plan, valid_filename

app = FastAPI(title="Music Transcription API", version="1.0.0")
origins = os.getenv("CORS_ORIGINS", "http://localhost:8080,http://localhost:3000").split(",")
app.add_middleware(CORSMiddleware, allow_origins=[o.strip() for o in origins], allow_methods=["GET", "POST"], allow_headers=["Content-Type"], allow_credentials=False)
log = logging.getLogger("studio")
processing_lock = threading.Lock()
MAX_UPLOAD_BYTES = 150 * 1024 * 1024


def run(command: list[str], timeout: int = 600) -> None:
    subprocess.run(command, check=True, capture_output=True, timeout=timeout)


def encode(path: Path) -> str:
    return base64.b64encode(path.read_bytes()).decode("ascii")


def mp3(source: Path, dest: Path) -> None:
    run(["ffmpeg", "-y", "-v", "error", "-i", str(source), "-codec:a", "libmp3lame", "-b:a", "192k", str(dest)])


@app.get("/health")
def health():
    return {"status": "ok", "busy": processing_lock.locked()}


@app.post("/transcribe")
def transcribe(
    file: UploadFile = File(...),
    target_stem: Literal["melody_lead", "accompaniment", "full_mix"] = Form("melody_lead"),
    clef: Literal["treble", "bass"] = Form("treble"),
    onset_threshold: float = Form(0.5, ge=0, le=1),
    frame_threshold: float = Form(0.3, ge=0, le=1),
    minimum_note_length: float = Form(127.7, gt=0, le=2000),
):
    if not file.filename or not valid_filename(file.filename):
        raise HTTPException(415, "Envie um arquivo MP4, MP3 ou WAV.")
    if not processing_lock.acquire(blocking=False):
        raise HTTPException(429, "O estúdio está processando outra música. Tente novamente em breve.")
    try:
        with tempfile.TemporaryDirectory(prefix="music-studio-") as folder:
            work = Path(folder)
            source = work / ("upload" + Path(file.filename).suffix.lower())
            total = 0
            with source.open("wb") as output:
                while chunk := file.file.read(1024 * 1024):
                    total += len(chunk)
                    if total > MAX_UPLOAD_BYTES:
                        raise HTTPException(413, "Arquivo excede 150 MB.")
                    output.write(chunk)
            if total == 0:
                raise HTTPException(400, "O arquivo está vazio.")
            wav = work / "original.wav"
            run(["ffmpeg", "-y", "-v", "error", "-i", str(source), "-vn", "-ar", "44100", "-ac", "2", str(wav)])
            import librosa
            import numpy as np
            import soundfile as sf
            from basic_pitch.inference import predict
            from music21 import converter, clef as clefs, meter, tempo

            selected, backing_stems = stem_plan(target_stem)
            chosen = wav
            backing = None
            if selected:
                run([sys.executable, "-m", "demucs", "-n", "htdemucs", "--device", os.getenv("DEMUCS_DEVICE", "cpu"), "-o", str(work / "separated"), str(wav)], timeout=1800)
                stem_dir = work / "separated" / "htdemucs" / "original"
                chosen = stem_dir / f"{selected}.wav"
                mixed = None
                rate = 44100
                for stem in backing_stems:
                    samples, rate = sf.read(stem_dir / f"{stem}.wav", dtype="float32", always_2d=True)
                    mixed = samples if mixed is None else mixed + samples
                if mixed is not None:
                    peak = float(np.max(np.abs(mixed)))
                    if peak > 1:
                        mixed = mixed / peak
                    backing = work / "backing.wav"
                    sf.write(backing, mixed, rate)

            audio, sr = librosa.load(chosen, sr=22050, mono=True)
            detected, _ = librosa.beat.beat_track(y=audio, sr=sr)
            bpm_value = float(np.asarray(detected).reshape(-1)[0])
            bpm = bpm_value if np.isfinite(bpm_value) and bpm_value > 0 else 120.0
            _, midi, events = predict(str(chosen), onset_threshold=onset_threshold, frame_threshold=frame_threshold, minimum_note_length=minimum_note_length)
            # Basic Pitch emits 120-BPM MIDI; preserve note seconds while assigning detected tempo.
            midi._tick_scales = [(0, 60.0 / (bpm * midi.resolution))]
            midi_path = work / "transcription.mid"
            midi.write(str(midi_path))
            score = converter.parse(str(midi_path))
            score.quantize(quarterLengthDivisors=(4, 2), inPlace=True, processOffsets=True, processDurations=True)
            chosen_clef = clefs.TrebleClef if clef == "treble" else clefs.BassClef
            suggested_key = None
            if len(events):
                suggested_key = score.analyze("key")
            # Meter estimation uses MIDI rhythmic offsets; 4/4 is a transparent fallback.
            from music21.analysis import metrical
            try:
                timesig = metrical.bestTimeSignature(score.flatten())
            except Exception:
                timesig = meter.TimeSignature("4/4")
            score.metadata = __import__("music21").metadata.Metadata()
            score.metadata.title = Path(file.filename).stem
            for part in score.parts:
                for old in list(part.recurse().getElementsByClass(clefs.Clef)):
                    old.activeSite.remove(old)
                for old in list(part.recurse().getElementsByClass(meter.TimeSignature)):
                    old.activeSite.remove(old)
                part.insert(0, chosen_clef())
                part.insert(0, meter.TimeSignature(timesig.ratioString))
                part.insert(0, tempo.MetronomeMark(number=bpm))
                if suggested_key:
                    part.insert(0, suggested_key)
            xml_path = work / "score.musicxml"
            score.write("musicxml", fp=str(xml_path))
            isolated = work / "isolated.mp3"
            mp3(chosen, isolated)
            backing_encoded = None
            if backing:
                backing_mp3 = work / "backing.mp3"
                mp3(backing, backing_mp3)
                backing_encoded = encode(backing_mp3)
            return {
                "musicxml": xml_path.read_text(encoding="utf-8"),
                "midi_base64": encode(midi_path),
                "isolated_audio_base64": encode(isolated),
                "backing_track_base64": backing_encoded,
                "metadata": {"bpm": round(bpm), "key": str(suggested_key) if suggested_key else "Indeterminada", "total_notes": len(events), "time_signature": timesig.ratioString},
            }
    except HTTPException:
        raise
    except subprocess.TimeoutExpired:
        raise HTTPException(504, "O processamento excedeu o tempo disponível. Tente uma gravação menor.")
    except subprocess.CalledProcessError:
        log.exception("Audio subprocess failed")
        raise HTTPException(422, "Não foi possível extrair ou separar o áudio. Confira o arquivo e a instalação do FFmpeg/Demucs.")
    except Exception:
        log.exception("Transcription failed")
        raise HTTPException(500, "Não foi possível transcrever. Consulte os registros da API e tente novamente.")
    finally:
        file.file.close()
        processing_lock.release()