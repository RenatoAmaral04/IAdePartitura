"""Pure pipeline rules, independently testable without ML dependencies."""
from pathlib import Path

ALLOWED_EXTENSIONS = {".mp4", ".mp3", ".wav"}
TARGETS = {"melody_lead", "accompaniment", "full_mix"}


def stem_plan(target: str) -> tuple[str | None, tuple[str, ...]]:
    if target == "melody_lead":
        return "vocals", ("drums", "bass", "other")
    if target == "accompaniment":
        return "other", ("other",)
    if target == "full_mix":
        return None, ()
    raise ValueError("Alvo inválido")


def valid_filename(filename: str) -> bool:
    return Path(filename).suffix.lower() in ALLOWED_EXTENSIONS