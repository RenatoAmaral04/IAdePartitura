# Entrega
- [x] Aplicar o nome escolhido: Partitura Studio.
- [x] Criar estúdio de upload, configuração, partitura e players.
- [x] Entregar API Python Demucs / Basic Pitch, Docker e guia.
- [x] Testar regras e fluxo visual; registrar limitações de execução.
- [x] Corrigir o fechamento JSX do player e os erros adicionais de TypeScript.
- [ ] Validar inferência real — depende do serviço Python com modelos instalados e conectado.