# Partitura Studio

Estúdio React/TypeScript com visualização MusicXML (OpenSheetMusicDisplay), upload de MP4/MP3/WAV, seleção de faixa e clave, ajustes Basic Pitch, dois players e exportações MusicXML/MIDI/impressão PDF. API Python independente em `backend/`, com Demucs htdemucs, Basic Pitch e music21.

## Rodar a API localmente

Requer Python **3.10**, FFmpeg no PATH, espaço para os modelos e RAM suficiente (8 GB ou mais recomendados). A primeira execução baixa o modelo Demucs; processamento em CPU pode levar vários minutos. Basic Pitch não garante identificação de solos instrumentais na faixa vocals: é uma aproximação dependente da mixagem.

```sh
cd backend
python3.10 -m venv .venv
source .venv/bin/activate
# Windows: .venv\Scripts\activate
pip install -r requirements.txt
# Ubuntu/Debian: sudo apt-get install ffmpeg libsndfile1
uvicorn main:app --host 0.0.0.0 --port 8000
```

Swagger: http://localhost:8000/docs. Saúde: http://localhost:8000/health.

## Docker

Na raiz do projeto:

```sh
docker build -t partitura-api ./backend
docker run --rm -p 8000:8000 \
  -e CORS_ORIGINS=http://localhost:8080 \
  -v partitura-models:/home/studio/.cache \
  partitura-api
```

Para GPU, use uma imagem PyTorch/CUDA compatível, runtime NVIDIA e `DEMUCS_DEVICE=cuda`. A imagem entregue usa CPU.

## Conectar o frontend

```sh
bun install
bun run dev
```

Abra http://localhost:8080. O endereço padrão é http://localhost:8000. Use o botão de configurações para testar e conectar outro endereço, ou crie `.env.local`:

```dotenv
VITE_TRANSCRIPTION_API_URL=https://seu-servico-de-audio.example.com
```

O valor acima ilustra a configuração: substitua pelo endereço real. Não inclua credenciais nessa variável. Reinicie a execução local após alterar o ambiente.

Em produção hospede a API Python separadamente em um servidor/container com recursos de CPU/GPU. O serviço Python **não roda na hospedagem do frontend**. Configure `CORS_ORIGINS` com as origens exatas do preview e do site publicado, separadas por vírgula. Um site HTTPS precisa de API HTTPS; localhost aponta para o computador do visitante. Configurações do botão valem para a sessão atual.

## Uso

1. Envie uma música, escolha melodia/solo, acompanhamento ou áudio completo e ajuste a clave.
2. Gere a partitura; as etapas exibidas são estimativas, não telemetria do servidor.
3. Ouça os dois áudios, baixe MP3/MIDI/MusicXML e imprima a partitura ou salve PDF pelo navegador.

A prévia inicial é um estudo gerado localmente, identificado como exemplo. “Ouvir exemplo” carrega áudio sintetizado WAV; não simula uma transcrição real. Resultados reais são exclusivamente retornados pela API.

## Contrato

`POST /transcribe`, multipart: `file`, `target_stem` (`melody_lead`, `accompaniment`, `full_mix`), `clef` (`treble`, `bass`), `onset_threshold` (0–1), `frame_threshold` (0–1), `minimum_note_length` (ms). Resposta: MusicXML completo, MIDI Base64, MP3 isolado Base64, MP3 acompanhamento Base64 e metadata BPM/tonalidade/notas/compasso.

- Melodia: transcreve vocals; acompanhamento é drums + bass + other.
- Harmonia: transcreve other; ambos os áudios correspondem à faixa harmônica.
- Mix completo: não separa; acompanhamento é `null` (não há como removê-lo sem separação).
- Quantização: semicolcheias/colcheias; compasso estimado com fallback 4/4. IA pode necessitar revisão.
- Limite: 150 MB; requisição síncrona, uma tarefa por processo, temporários apagados após sucesso ou erro. Cancelar no navegador não interrompe a tarefa Python.

## Testes e implantação

```sh
bunx vitest run src/test/transcription.test.ts src/test/app-routing.test.tsx
cd backend
python -m unittest test_audio_rules.py
```

Os testes de regras não executam inferência ML. Para validar a instalação completa, envie uma gravação curta pelos três modos e confira a resposta e o som dos arquivos exportados. A inferência real depende das bibliotecas/modelos instalados; não foi executada no ambiente da entrega. Ajuste timeouts do proxy para tarefas longas (até 30 minutos na separação), coloque autenticação e limitação de tráfego no proxy antes de expor a API publicamente, e dimensione para o tamanho dos retornos Base64. CORS não é autenticação.
